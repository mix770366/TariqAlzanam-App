package com.example.repository

import android.util.Log
import com.example.model.AyOrder
import com.example.model.OrderStatus
import com.example.model.ProductItem
import com.example.model.ServiceType
import com.example.model.VendorStore
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

/**
 * Cloud Firestore integration for:
 * - Unique Customer registration (prevents duplicate phone registration)
 * - Merchant registration & live product/offer uploads
 * - Driver registration & direct ride acceptance (with name + plate number)
 * - Real-time order upload & status/driver sync
 */
class CloudOrdersService {

    companion object {
        // Local fallback registry so duplicate-phone check works even before google-services.json is configured
        private val localRegisteredPhones = mutableMapOf<String, String>()
    }

    private fun getFirestoreOrNull(): FirebaseFirestore? {
        return runCatching {
            if (FirebaseApp.getApps().isEmpty()) null
            else FirebaseFirestore.getInstance()
        }.getOrNull()
    }

    fun registerCustomerIfUnique(
        name: String,
        phone: String,
        allowExistingLogin: Boolean = false,
        onResult: (success: Boolean, resolvedName: String, message: String) -> Unit
    ) {
        val cleanPhone = phone.trim()
        val cleanName = name.trim()
        val db = getFirestoreOrNull()

        if (db == null) {
            val existing = localRegisteredPhones[cleanPhone]
            if (existing != null && !allowExistingLogin) {
                onResult(false, existing, "رقم الهاتف ($cleanPhone) مسجل مسبقاً! يمكنك تسجيل الدخول أو استخدام رقم آخر.")
            } else {
                val finalName = existing ?: cleanName
                localRegisteredPhones[cleanPhone] = finalName
                onResult(true, finalName, if (existing != null) "مرحباً بعودتك، $finalName!" else "تم تسجيل حسابك بنجاح!")
            }
            return
        }

        val docRef = db.collection("customers").document(cleanPhone)
        docRef.get()
            .addOnSuccessListener { doc ->
                if (doc.exists()) {
                    val existingName = doc.getString("name") ?: cleanName
                    if (!allowExistingLogin) {
                        onResult(false, existingName, "رقم الهاتف ($cleanPhone) مسجل مسبقاً! اضغط دخول بحسابك أو استخدم رقماً آخر.")
                    } else {
                        onResult(true, existingName, "مرحباً بعودتك، $existingName!")
                    }
                } else {
                    val data = hashMapOf(
                        "name" to cleanName,
                        "phone" to cleanPhone,
                        "createdAtEpochMs" to System.currentTimeMillis()
                    )
                    docRef.set(data)
                        .addOnSuccessListener {
                            localRegisteredPhones[cleanPhone] = cleanName
                            onResult(true, cleanName, "تم إنشاء حساب العميل بنجاح!")
                        }
                        .addOnFailureListener { e ->
                            onResult(true, cleanName, "تم الدخول محلياً (${e.localizedMessage ?: "بدون سحابة"})")
                        }
                }
            }
            .addOnFailureListener {
                onResult(true, cleanName, "تم الدخول محلياً بنجاح!")
            }
    }

    fun registerMerchantStore(
        store: VendorStore,
        ownerPhone: String,
        onComplete: (Boolean, String) -> Unit
    ) {
        val db = getFirestoreOrNull()
        if (db == null) {
            onComplete(true, "تم تسجيل متجرك محلياً بنجاح!")
            return
        }

        val storePayload = hashMapOf(
            "id" to store.id,
            "nameAr" to store.nameAr,
            "serviceType" to store.serviceType.id,
            "areaAr" to store.areaAr,
            "ownerPhone" to ownerPhone,
            "rating" to store.rating,
            "reviewCount" to store.reviewCount,
            "deliveryTimeMinutes" to store.deliveryTimeMinutes,
            "deliveryFeeYer" to store.deliveryFeeYer,
            "tagAr" to store.tagAr,
            "isOpen" to store.isOpen,
            "createdAtEpochMs" to System.currentTimeMillis()
        )
        db.collection("stores").document(store.id).set(storePayload)
            .addOnSuccessListener { onComplete(true, "تم تسجيل متجرك على السحابة بنجاح!") }
            .addOnFailureListener { onComplete(true, "تم تسجيل متجرك محلياً بنجاح!") }
    }

    fun addMerchantProduct(
        storeId: String,
        product: ProductItem,
        onComplete: (Boolean) -> Unit
    ) {
        val db = getFirestoreOrNull()
        if (db == null) {
            onComplete(true)
            return
        }
        val payload = hashMapOf(
            "id" to product.id,
            "vendorId" to storeId,
            "nameAr" to product.nameAr,
            "descriptionAr" to product.descriptionAr,
            "priceYer" to product.priceYer,
            "originalPriceYer" to product.originalPriceYer,
            "categoryNameAr" to product.categoryNameAr,
            "isPopular" to product.isPopular,
            "unitAr" to product.unitAr,
            "createdAtEpochMs" to System.currentTimeMillis()
        )
        db.collection("stores").document(storeId)
            .collection("products").document(product.id)
            .set(payload)
            .addOnSuccessListener { onComplete(true) }
            .addOnFailureListener { onComplete(true) }
    }

    fun uploadOrder(
        order: AyOrder,
        customerName: String,
        customerPhone: String,
        targetVendorName: String
    ) {
        val db = getFirestoreOrNull() ?: return
        val itemsSummary = if (order.items.isNotEmpty()) {
            order.items.joinToString(" | ") { "${it.quantity}x ${it.product.nameAr}" }
        } else {
            order.customNotesAr
        }

        val payload = hashMapOf(
            "id" to order.id,
            "customerName" to customerName.ifBlank { "عميل طارق الزنم" },
            "customerPhone" to customerPhone.ifBlank { "غير محدد" },
            "serviceType" to order.serviceType.id,
            "serviceTitleAr" to order.serviceType.titleAr,
            "targetVendorName" to targetVendorName,
            "titleAr" to order.titleAr,
            "pickupDistrictAr" to order.pickupDistrictAr,
            "dropoffDistrictAr" to order.dropoffDistrictAr,
            "itemsSummary" to itemsSummary,
            "customNotesAr" to order.customNotesAr,
            "deliveryFeeYer" to order.deliveryFeeYer,
            "itemsSubtotalYer" to order.itemsSubtotalYer,
            "totalAmountYer" to order.totalAmountYer,
            "paymentMethodAr" to order.paymentMethodAr,
            "transferReference" to order.transferReference,
            "vehicleTypeAr" to order.courierVehicleAr,
            "courierNameAr" to order.courierNameAr,
            "courierPhone" to order.courierPhone,
            "driverPlateNumber" to order.driverPlateNumber,
            "status" to order.status.name,
            "statusTitleAr" to order.status.titleAr,
            "createdAt" to order.createdAt,
            "createdAtEpochMs" to System.currentTimeMillis(),
            "isUrgent" to order.isUrgent
        )

        db.collection("orders")
            .document(order.id)
            .set(payload)
            .addOnFailureListener { e ->
                Log.w("CloudOrdersService", "Firestore upload failed: ${e.message}")
            }
    }

    fun acceptRideAsDriver(
        orderId: String,
        driverName: String,
        driverPhone: String,
        vehicleType: String,
        plateNumber: String
    ) {
        val db = getFirestoreOrNull() ?: return
        db.collection("orders")
            .document(orderId)
            .update(
                mapOf(
                    "status" to OrderStatus.COURIER_ASSIGNED.name,
                    "statusTitleAr" to OrderStatus.COURIER_ASSIGNED.titleAr,
                    "courierNameAr" to driverName,
                    "courierPhone" to driverPhone,
                    "vehicleTypeAr" to vehicleType,
                    "driverPlateNumber" to plateNumber
                )
            )
            .addOnFailureListener { e ->
                Log.w("CloudOrdersService", "Driver accept update failed: ${e.message}")
            }
    }

    fun updateOrderStatus(orderId: String, status: OrderStatus) {
        val db = getFirestoreOrNull() ?: return
        db.collection("orders")
            .document(orderId)
            .update(
                mapOf(
                    "status" to status.name,
                    "statusTitleAr" to status.titleAr
                )
            )
            .addOnFailureListener { e ->
                Log.w("CloudOrdersService", "Firestore status update failed: ${e.message}")
            }
    }

    fun observeOrderStatus(
        orderId: String,
        onStatusChanged: (OrderStatus) -> Unit
    ): ListenerRegistration? {
        val db = getFirestoreOrNull() ?: return null
        return db.collection("orders")
            .document(orderId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null || !snapshot.exists()) return@addSnapshotListener
                val statusName = snapshot.getString("status") ?: return@addSnapshotListener
                val parsed = runCatching { OrderStatus.valueOf(statusName) }.getOrNull() ?: return@addSnapshotListener
                onStatusChanged(parsed)
            }
    }

    fun observeOrderDetails(
        orderId: String,
        onUpdated: (status: OrderStatus?, driverName: String?, driverPhone: String?, vehicle: String?, plate: String?) -> Unit
    ): ListenerRegistration? {
        val db = getFirestoreOrNull() ?: return null
        return db.collection("orders")
            .document(orderId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null || !snapshot.exists()) return@addSnapshotListener
                val statusName = snapshot.getString("status")
                val parsed = statusName?.let { runCatching { OrderStatus.valueOf(it) }.getOrNull() }
                onUpdated(
                    parsed,
                    snapshot.getString("courierNameAr"),
                    snapshot.getString("courierPhone"),
                    snapshot.getString("vehicleTypeAr"),
                    snapshot.getString("driverPlateNumber")
                )
            }
    }
}
