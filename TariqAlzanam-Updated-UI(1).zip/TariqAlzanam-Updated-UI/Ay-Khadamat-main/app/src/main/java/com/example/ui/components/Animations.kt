package com.example.ui.components

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.R
import com.example.ui.Screen
import com.example.ui.theme.DarkBgPrimary
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldPrimary
import kotlinx.coroutines.delay

/**
 * Custom winged helmet logo emblem matching the "طارق الزنم" brand identity.
 */
@Composable
fun TariqLogoEmblem(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    animated: Boolean = false
) {
    val infiniteTransition = rememberInfiniteTransition(label = "LogoGlow")
    val glowScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (animated) 1.05f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "GlowScale"
    )

    Image(
        painter = painterResource(id = R.drawable.tariq_logo),
        contentDescription = "شعار طارق الزنم",
        contentScale = ContentScale.Crop,
        modifier = modifier
            .size(size)
            .scale(glowScale)
            .clip(RoundedCornerShape(size * 0.24f))
            .border(1.2.dp, GoldPrimary.copy(alpha = 0.7f), RoundedCornerShape(size * 0.24f))
    )
}

/**
 * Spring bounce press animation for interactive cards & buttons.
 */
fun Modifier.bounceClick(
    scaleDown: Float = 0.96f,
    onClick: () -> Unit
): Modifier = composed {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) scaleDown else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "BounceScale"
    )
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = interactionSource,
            indication = null,
            onClick = onClick
        )
}

/**
 * Staggered entrance animation (slide up + fade in) for cards and list rows.
 */
@Composable
fun AnimatedEntrance(
    index: Int = 0,
    delayPerItemMs: Int = 35,
    content: @Composable () -> Unit
) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        if (index > 0) {
            delay((index.coerceAtMost(8) * delayPerItemMs).toLong())
        }
        visible = true
    }

    val alpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
        label = "EntranceAlpha"
    )
    val translationY by animateFloatAsState(
        targetValue = if (visible) 0f else 28f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "EntranceOffset"
    )

    Box(
        modifier = Modifier.graphicsLayer {
            this.alpha = alpha
            this.translationY = translationY
        }
    ) {
        content()
    }
}

/**
 * Luxury Gold Gradient CTA Button with subtle shimmer/press bounce.
 */
@Composable
fun GoldGradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    subtitle: String? = null,
    height: Dp = 50.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "GoldShimmer")
    val shimmerShift by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 600f,
        animationSpec = infiniteRepeatable(
            animation = tween(2600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ShimmerShift"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(GoldBright, GoldPrimary, GoldDark, GoldPrimary),
                    start = Offset(shimmerShift - 300f, 0f),
                    end = Offset(shimmerShift + 300f, 120f)
                )
            )
            .bounceClick(onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = DarkBgPrimary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                color = DarkBgPrimary,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp
            )
            if (subtitle != null) {
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = subtitle,
                    color = DarkBgPrimary.copy(alpha = 0.78f),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp
                )
            }
        }
    }
}

/**
 * Screen-to-screen directional transition ("الحركات من وإلى").
 */
fun screenTransitionSpec(
    initialState: Screen,
    targetState: Screen
): ContentTransform {
    val tabOrder = mapOf(
        Screen.HOME to 0,
        Screen.SERVICES_LIST to 1,
        Screen.CUSTOM_ORDER to 2,
        Screen.ORDERS to 3,
        Screen.GUARANTEE_INFO to 4,
        Screen.RIDES_AND_TRAVEL to 5,
        Screen.STORE_DETAIL to 5,
        Screen.ORDER_TRACKING to 6
    )
    val fromIdx = tabOrder[initialState] ?: 0
    val toIdx = tabOrder[targetState] ?: 0

    // Detail screens zoom + fade in smoothly
    if (targetState == Screen.STORE_DETAIL || targetState == Screen.ORDER_TRACKING) {
        return (slideInVertically(
            animationSpec = tween(320, easing = FastOutSlowInEasing),
            initialOffsetY = { it / 6 }
        ) + fadeIn(tween(260)) + scaleIn(initialScale = 0.96f, animationSpec = tween(300))) togetherWith
            (fadeOut(tween(200)) + scaleOut(targetScale = 0.98f, animationSpec = tween(200)))
    }

    val forward = toIdx >= fromIdx
    return (slideInHorizontally(
        animationSpec = tween(300, easing = FastOutSlowInEasing),
        initialOffsetX = { fullWidth -> if (forward) fullWidth / 4 else -fullWidth / 4 }
    ) + fadeIn(tween(280))) togetherWith
        (slideOutHorizontally(
            animationSpec = tween(240, easing = FastOutSlowInEasing),
            targetOffsetX = { fullWidth -> if (forward) -fullWidth / 5 else fullWidth / 5 }
        ) + fadeOut(tween(220)))
}
