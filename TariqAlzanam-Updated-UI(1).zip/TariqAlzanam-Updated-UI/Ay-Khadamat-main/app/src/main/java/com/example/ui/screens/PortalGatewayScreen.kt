package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ServiceType
import com.example.model.UserRole
import com.example.ui.components.AnimatedEntrance
import com.example.ui.components.GoldGradientButton
import com.example.ui.components.TariqLogoEmblem
import com.example.ui.components.bounceClick
import com.example.ui.dialogs.LocationSelectorDialog
import com.example.ui.theme.DarkBgPrimary
import com.example.ui.theme.DarkCardElevated
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkOutlineGold
import com.example.ui.theme.DarkOutlineSubtle
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldContainerDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.RedUrgent
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun PortalGatewayScreen(
    onCustomerRegister: (name: String, phone: String, allowExisting: Boolean, onResult: (Boolean, String) -> Unit) -> Unit,
    onMerchantRegister: (storeName: String, serviceType: ServiceType, areaAr: String, phone: String) -> Unit,
    onDriverRegister: (name: String, phone: String, vehicleType: String, plateNumber: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedRole by remember { mutableStateOf<UserRole?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBgPrimary)
            .padding(horizontal = 18.dp, vertical = 20.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (selectedRole != null) {
                    IconButton(onClick = { selectedRole = null }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع", tint = GoldPrimary)
                    }
                } else {
                    TariqLogoEmblem(size = 44.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                }
                Column {
                    Text(
                        text = selectedRole?.let { "تسجيل ${it.titleAr}" } ?: "بوابة الدخول • طارق الزنم",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextWhite
                    )
                    Text(
                        text = selectedRole?.let { "أكمل بياناتك للدخول المباشر" } ?: "اختر نوع حسابك للبدء",
                        fontSize = 12.sp,
                        color = GoldBright
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Box(modifier = Modifier.weight(1f)) {
        AnimatedContent(
            targetState = selectedRole,
            transitionSpec = { fadeIn(tween(240)) togetherWith fadeOut(tween(180)) },
            label = "RoleGatewaySwitch"
        ) { role ->
            if (role == null) {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    item {
                        AnimatedEntrance(index = 0) {
                            RoleChoiceCard(
                                title = "بوابة العميل",
                                subtitle = "اطلب وجبات، مقاضي، مشاوير، وتذاكر سفر بكل سهولة",
                                badge = "تصفح واطلب الآن",
                                icon = Icons.Default.Person,
                                onClick = { selectedRole = UserRole.CUSTOMER }
                            )
                        }
                    }
                    item {
                        AnimatedEntrance(index = 1) {
                            RoleChoiceCard(
                                title = "بوابة البائع / صاحب المحل",
                                subtitle = "سجّل محلك وارفع منتجاتك وعروضك وحدد أسعارك بنفسك",
                                badge = "إدارة المتجر",
                                icon = Icons.Default.Store,
                                onClick = { selectedRole = UserRole.MERCHANT }
                            )
                        }
                    }
                    item {
                        AnimatedEntrance(index = 2) {
                            RoleChoiceCard(
                                title = "بوابة السائق / الكابتن",
                                subtitle = "استقبل طلبات النقل (متر، دباب، سيارة، باص) وأكّد برقم لوحتك",
                                badge = "قبول المشاوير",
                                icon = Icons.Default.DirectionsCar,
                                onClick = { selectedRole = UserRole.DRIVER }
                            )
                        }
                    }
                }
            } else {
                when (role) {
                    UserRole.CUSTOMER -> CustomerRegisterForm(onSubmit = onCustomerRegister)
                    UserRole.MERCHANT -> MerchantRegisterForm(onSubmit = onMerchantRegister)
                    UserRole.DRIVER -> DriverRegisterForm(onSubmit = onDriverRegister)
                }
            }
        }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "هندسة وتطوير: محمد معزب • جميع الحقوق محفوظة © 2026",
            fontSize = 11.sp,
            color = TextMuted,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
private fun RoleChoiceCard(
    title: String,
    subtitle: String,
    badge: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .bounceClick { onClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
        border = BorderStroke(1.2.dp, DarkOutlineGold),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(GoldContainerDark)
                    .border(1.dp, GoldPrimary, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = GoldPrimary, modifier = Modifier.size(30.dp))
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = TextWhite)
                Spacer(modifier = Modifier.height(4.dp))
                Text(subtitle, fontSize = 12.sp, color = TextMuted, lineHeight = 18.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(GoldPrimary)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(badge, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = DarkBgPrimary)
                }
            }
        }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "هندسة وتطوير: محمد معزب • جميع الحقوق محفوظة © 2026",
            fontSize = 11.sp,
            color = TextMuted,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
private fun CustomerRegisterForm(
    onSubmit: (name: String, phone: String, allowExisting: Boolean, onResult: (Boolean, String) -> Unit) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var showExistingLoginOption by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "سجّل اسمك ورقم هاتفك (رقم الهاتف يُسجل مرة واحدة فقط لمنع التكرار):",
            fontSize = 13.sp,
            color = TextMuted
        )

        OutlinedTextField(
            value = name,
            onValueChange = { name = it; errorMsg = null },
            label = { Text("الاسم الكامل") },
            leadingIcon = { Icon(Icons.Default.Person, null, tint = GoldPrimary) },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextWhite, unfocusedTextColor = TextWhite,
                focusedBorderColor = GoldPrimary, unfocusedBorderColor = DarkOutlineSubtle
            ),
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it; errorMsg = null; showExistingLoginOption = false },
            label = { Text("رقم الهاتف (مثال: 777123456)") },
            leadingIcon = { Icon(Icons.Default.Phone, null, tint = GoldPrimary) },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextWhite, unfocusedTextColor = TextWhite,
                focusedBorderColor = GoldPrimary, unfocusedBorderColor = DarkOutlineSubtle
            ),
            modifier = Modifier.fillMaxWidth()
        )

        if (errorMsg != null) {
            Text(errorMsg!!, color = RedUrgent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        GoldGradientButton(
            text = "تسجيل ودخول للتطبيق",
            onClick = {
                if (name.isBlank() || phone.trim().length < 7) {
                    errorMsg = "يرجى كتابة الاسم ورقم الهاتف الصحيح"
                    return@GoldGradientButton
                }
                onSubmit(name, phone, false) { ok, msg ->
                    if (!ok) {
                        errorMsg = msg
                        showExistingLoginOption = true
                    }
                }
            }
        )

        if (showExistingLoginOption) {
            OutlinedButton(
                onClick = {
                    onSubmit(name, phone, true) { _, _ -> }
                },
                border = BorderStroke(1.dp, GoldPrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text("دخول بحسابي المسجل بهذا الرقم", color = GoldBright, fontWeight = FontWeight.Bold)
            }
        }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "هندسة وتطوير: محمد معزب • جميع الحقوق محفوظة © 2026",
            fontSize = 11.sp,
            color = TextMuted,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
private fun MerchantRegisterForm(
    onSubmit: (storeName: String, serviceType: ServiceType, areaAr: String, phone: String) -> Unit
) {
    var storeName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var areaAr by remember { mutableStateOf("إب - شارع تعز") }
    var selectedCategory by remember { mutableStateOf(ServiceType.RESTAURANTS) }
    var showAreaPicker by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    if (showAreaPicker) {
        LocationSelectorDialog(
            currentDistrict = areaAr,
            onSelectDistrict = { areaAr = it; showAreaPicker = false },
            onDismiss = { showAreaPicker = false },
            titleText = "اختر موقع المحل (المحافظة والمنطقة)"
        )
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            OutlinedTextField(
                value = storeName,
                onValueChange = { storeName = it; errorMsg = null },
                label = { Text("اسم المحل أو المطعم") },
                leadingIcon = { Icon(Icons.Default.Store, null, tint = GoldPrimary) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextWhite, unfocusedTextColor = TextWhite,
                    focusedBorderColor = GoldPrimary, unfocusedBorderColor = DarkOutlineSubtle
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it; errorMsg = null },
                label = { Text("رقم هاتف المحل للتواصل") },
                leadingIcon = { Icon(Icons.Default.Phone, null, tint = GoldPrimary) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextWhite, unfocusedTextColor = TextWhite,
                    focusedBorderColor = GoldPrimary, unfocusedBorderColor = DarkOutlineSubtle
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth().clickable { showAreaPicker = true },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                border = BorderStroke(0.8.dp, DarkOutlineGold)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, null, tint = GoldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("عنوان المحل:", fontSize = 11.sp, color = TextMuted)
                            Text(areaAr, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                        }
                    }
                    Text("تغيير", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
                }
            }
        }

        item {
            Text("اختر قسم النشاط:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldBright)
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ServiceType.entries.take(9)) { cat ->
                    val isSel = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSel) GoldPrimary else DarkCardSurface)
                            .border(1.dp, if (isSel) GoldPrimary else DarkOutlineSubtle, RoundedCornerShape(10.dp))
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = cat.titleAr,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSel) DarkBgPrimary else TextWhite
                        )
                    }
                }
            }
        }

        if (errorMsg != null) {
            item { Text(errorMsg!!, color = RedUrgent, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        }

        item {
            GoldGradientButton(
                text = "إنشاء المتجر والدخول لرفع المنتجات",
                onClick = {
                    if (storeName.isBlank() || phone.trim().length < 7) {
                        errorMsg = "يرجى إدخال اسم المحل ورقم الهاتف"
                        return@GoldGradientButton
                    }
                    onSubmit(storeName.trim(), selectedCategory, areaAr, phone.trim())
                }
            )
        }
    }
}

@Composable
private fun DriverRegisterForm(
    onSubmit: (name: String, phone: String, vehicleType: String, plateNumber: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var plateNumber by remember { mutableStateOf("") }
    val vehicleTypes = listOf("دراجة نارية / متر", "دباب", "سيارة خاصة", "باص")
    var selectedVehicle by remember { mutableStateOf(vehicleTypes[0]) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it; errorMsg = null },
                label = { Text("اسم السائق / الكابتن") },
                leadingIcon = { Icon(Icons.Default.Person, null, tint = GoldPrimary) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextWhite, unfocusedTextColor = TextWhite,
                    focusedBorderColor = GoldPrimary, unfocusedBorderColor = DarkOutlineSubtle
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it; errorMsg = null },
                label = { Text("رقم الهاتف") },
                leadingIcon = { Icon(Icons.Default.Phone, null, tint = GoldPrimary) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextWhite, unfocusedTextColor = TextWhite,
                    focusedBorderColor = GoldPrimary, unfocusedBorderColor = DarkOutlineSubtle
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Text("نوع المركبة:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldBright)
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vehicleTypes) { v ->
                    val isSel = selectedVehicle == v
                    val vIcon = when (v) {
                        "دراجة نارية / متر" -> Icons.Default.DirectionsBike
                        "دباب" -> Icons.Default.LocalShipping
                        "باص" -> Icons.Default.DirectionsBus
                        else -> Icons.Default.DirectionsCar
                    }
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSel) GoldPrimary else DarkCardSurface)
                            .border(1.dp, if (isSel) GoldPrimary else DarkOutlineSubtle, RoundedCornerShape(10.dp))
                            .clickable { selectedVehicle = v }
                            .padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(vIcon, null, tint = if (isSel) DarkBgPrimary else GoldPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(v, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isSel) DarkBgPrimary else TextWhite)
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = plateNumber,
                onValueChange = { plateNumber = it; errorMsg = null },
                label = { Text("رقم اللوحة (سيظهر للعميل عند قبول الطلب)") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextWhite, unfocusedTextColor = TextWhite,
                    focusedBorderColor = GoldPrimary, unfocusedBorderColor = DarkOutlineSubtle
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (errorMsg != null) {
            item { Text(errorMsg!!, color = RedUrgent, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        }

        item {
            GoldGradientButton(
                text = "دخول لبوابة السائقين",
                onClick = {
                    if (name.isBlank() || phone.trim().length < 7 || plateNumber.isBlank()) {
                        errorMsg = "يرجى إدخال اسم السائق ورقم الهاتف ورقم اللوحة"
                        return@GoldGradientButton
                    }
                    onSubmit(name, phone, selectedVehicle, plateNumber)
                }
            )
        }
    }
}
