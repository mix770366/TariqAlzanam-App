package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AyOrder
import com.example.model.OrderStatus
import com.example.ui.components.GoldGradientButton
import com.example.ui.theme.DarkBgPrimary
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkOutlineGold
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun DriverPortalScreen(
    driverName: String,
    driverPhone: String,
    vehicleType: String,
    plateNumber: String,
    orders: List<AyOrder>,
    onAcceptRide: (orderId: String) -> Unit,
    onSwitchPortal: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeOrders = orders.filter { it.status != OrderStatus.DELIVERED && it.status != OrderStatus.CANCELLED }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBgPrimary),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                border = BorderStroke(1.dp, DarkOutlineGold)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.DirectionsCar, null, tint = GoldPrimary, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(driverName, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = TextWhite)
                            Text("$vehicleType • لوحة: $plateNumber", fontSize = 12.sp, color = GoldBright)
                        }
                    }

                    OutlinedButton(
                        onClick = onSwitchPortal,
                        border = BorderStroke(1.dp, GoldPrimary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.SwapHoriz, null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تبديل", fontSize = 11.sp, color = GoldPrimary, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Text(
                text = "طلبات النقل والتوصيل المتاحة (${activeOrders.size})",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = GoldBright
            )
        }

        items(activeOrders) { order ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                border = BorderStroke(1.dp, DarkOutlineGold)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(order.titleAr, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                        Text(order.status.titleAr, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoldBright)
                    }
                    Text("المركبة المطلوبة: ${order.courierVehicleAr}", fontSize = 12.sp, color = GoldPrimary)
                    Text("من: ${order.pickupDistrictAr}  ←  إلى: ${order.dropoffDistrictAr}", fontSize = 12.sp, color = TextMuted)
                    Text("الدفع: ${order.paymentMethodAr} • الأجرة: ${order.totalAmountYer} ريال", fontSize = 12.sp, color = SuccessGreen)

                    Spacer(modifier = Modifier.height(6.dp))

                    if (order.status == OrderStatus.PENDING) {
                        GoldGradientButton(
                            text = "قبول الطلب وإرسال اسمي ولوحتي",
                            icon = Icons.Default.CheckCircle,
                            onClick = { onAcceptRide(order.id) },
                            height = 44.dp
                        )
                    } else {
                        Text(
                            text = "الكابتن المعين: ${order.courierNameAr} ${if (order.driverPlateNumber.isNotBlank()) "(لوحة: ${order.driverPlateNumber})" else ""}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = GoldBright
                        )
                    }
                }
            }
        }
    }
}
