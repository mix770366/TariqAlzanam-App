package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.LocalMall
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PersonPinCircle
import androidx.compose.material.icons.filled.PhoneIphone
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ProductItem
import com.example.model.ServiceType
import com.example.model.VendorStore
import com.example.ui.theme.DarkBgPrimary
import com.example.ui.theme.DarkCardElevated
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkOutlineGold
import com.example.ui.theme.DarkOutlineSubtle
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldContainerDark
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldGuarantee
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

fun getServiceIcon(serviceType: ServiceType): ImageVector {
    return when (serviceType) {
        ServiceType.RESTAURANTS -> Icons.Default.Restaurant
        ServiceType.RETAIL_STORES -> Icons.Default.Store
        ServiceType.SUPERMARKET -> Icons.Default.ShoppingCart
        ServiceType.FRESH_PRODUCE -> Icons.Default.Eco
        ServiceType.SHOPPING_MALLS -> Icons.Default.LocalMall
        ServiceType.PHARMACY -> Icons.Default.LocalPharmacy
        ServiceType.ELECTRONICS -> Icons.Default.PhoneIphone
        ServiceType.GIFTS_AND_FLOWERS -> Icons.Default.CardGiftcard
        ServiceType.FASHION_TAILORING -> Icons.Default.Checkroom
        ServiceType.PARCEL_SHIPPING -> Icons.Default.LocalShipping
        ServiceType.CONFIDENTIAL_DOCUMENTS -> Icons.Default.Lock
        ServiceType.CUSTOM_ERRANDS -> Icons.Default.PersonPinCircle
    }
}

fun getServiceColors(serviceType: ServiceType): Pair<Color, Color> {
    return when (serviceType) {
        ServiceType.RESTAURANTS -> Pair(GoldPrimary, GoldBright)
        ServiceType.RETAIL_STORES -> Pair(Color(0xFF38BDF8), Color(0xFF7DD3FC))
        ServiceType.SUPERMARKET -> Pair(SuccessGreen, Color(0xFF86EFAC))
        ServiceType.FRESH_PRODUCE -> Pair(Color(0xFF34D399), Color(0xFF6EE7B7))
        ServiceType.SHOPPING_MALLS -> Pair(Color(0xFFA78BFA), Color(0xFFC4B5FD))
        ServiceType.PHARMACY -> Pair(Color(0xFFF43F5E), Color(0xFFFDA4AF))
        ServiceType.ELECTRONICS -> Pair(Color(0xFF38BDF8), Color(0xFFBAE6FD))
        ServiceType.GIFTS_AND_FLOWERS -> Pair(Color(0xFFEC4899), Color(0xFFF9A8D4))
        ServiceType.FASHION_TAILORING -> Pair(GoldBright, GoldDark)
        ServiceType.PARCEL_SHIPPING -> Pair(GoldPrimary, GoldDark)
        ServiceType.CONFIDENTIAL_DOCUMENTS -> Pair(Color(0xFF60A5FA), Color(0xFF93C5FD))
        ServiceType.CUSTOM_ERRANDS -> Pair(GoldBright, GoldPrimary)
    }
}

/**
 * 3-column luxury dark & gold service category tile matching the user's reference screens.
 */
@Composable
fun ServiceCategoryCard(
    service: ServiceType,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (accentColor, _) = getServiceColors(service)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .bounceClick { onClick() }
            .testTag("service_card_${service.id}"),
        colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
        border = BorderStroke(1.dp, DarkOutlineGold),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                accentColor.copy(alpha = 0.26f),
                                DarkCardElevated
                            )
                        )
                    )
                    .border(0.8.dp, GoldPrimary.copy(alpha = 0.45f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = getServiceIcon(service),
                    contentDescription = service.titleAr,
                    tint = GoldPrimary,
                    modifier = Modifier.size(26.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = service.titleAr,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = TextWhite
                ),
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(3.dp))

            Text(
                text = service.badgeAr,
                fontSize = 9.sp,
                fontWeight = FontWeight.SemiBold,
                color = GoldBright.copy(alpha = 0.85f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun GuaranteeBannerCard(
    onDetailsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .bounceClick { onDetailsClick() }
            .testTag("guarantee_banner_card"),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        border = BorderStroke(1.dp, DarkOutlineGold),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            DarkCardSurface,
                            DarkCardElevated,
                            GoldContainerDark
                        )
                    )
                )
                .padding(14.dp)
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(GoldPrimary.copy(alpha = 0.18f))
                                .border(1.dp, GoldPrimary.copy(alpha = 0.6f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = "ضمان",
                                tint = GoldPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "ضمان طارق الزنم الشامل",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            )
                            Text(
                                text = "«التوصيل لكل هذا أنا له ضامن»",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = GoldBright,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(GoldPrimary)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "التفاصيل",
                            color = DarkBgPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    GuaranteePill(icon = Icons.Default.Thermostat, text = "حقائب حرارية")
                    GuaranteePill(icon = Icons.Default.Security, text = "حماية ضد الصدمات")
                    GuaranteePill(icon = Icons.Default.Lock, text = "سرية وتوقيع رسمي")
                }
            }
        }
    }
}

@Composable
private fun GuaranteePill(icon: ImageVector, text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(DarkBgPrimary.copy(alpha = 0.6f))
            .border(0.5.dp, DarkOutlineGold, RoundedCornerShape(10.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = GoldPrimary,
            modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = text,
            color = TextWhite,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

/**
 * Dark & Gold Vendor Store Card matching the reference screenshots (ratings in gold, "مفتوح الآن" in green, gold CTA pill).
 */
@Composable
fun StoreCard(
    store: VendorStore,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .bounceClick { onClick() }
            .testTag("store_card_${store.id}"),
        colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
        border = BorderStroke(0.9.dp, DarkOutlineGold),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left/Start Icon Box
            Box(
                modifier = Modifier
                    .size(66.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(DarkCardElevated, GoldContainerDark)
                        )
                    )
                    .border(1.dp, GoldPrimary.copy(alpha = 0.45f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = getServiceIcon(store.serviceType),
                    contentDescription = store.serviceType.titleAr,
                    tint = GoldPrimary,
                    modifier = Modifier.size(32.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Middle Details
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = store.nameAr,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextWhite
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(3.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "تقييم",
                        tint = GoldPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "${store.rating} (${store.reviewCount} تقييم)",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp,
                        color = GoldBright
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (store.isOpen) "مفتوح الآن" else "مغلق",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (store.isOpen) SuccessGreen else TextMuted
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "${store.areaAr} • ${store.deliveryTimeMinutes}",
                        fontSize = 11.sp,
                        color = TextMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Gold Pill CTA ("اطلب الآن")
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(Brush.horizontalGradient(listOf(GoldBright, GoldPrimary)))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ShoppingCart,
                        contentDescription = null,
                        tint = DarkBgPrimary,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "اطلب الآن",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = DarkBgPrimary
                    )
                }
            }
        }
    }
}

@Composable
fun ProductCard(
    product: ProductItem,
    onAddToCart: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("product_card_${product.id}"),
        colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
        border = BorderStroke(0.8.dp, DarkOutlineSubtle),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = product.nameAr,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextWhite
                        )
                    )
                    if (product.isPopular) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(GoldContainerDark)
                                .border(0.5.dp, DarkOutlineGold, RoundedCornerShape(4.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "موصى به 🔥",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoldBright
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = product.descriptionAr,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 12.sp,
                        color = TextMuted
                    ),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${product.priceYer} ريال يمني",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = GoldPrimary
                    )

                    if (product.originalPriceYer != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${product.originalPriceYer} ريال",
                            fontSize = 11.sp,
                            color = TextMuted,
                            textDecoration = TextDecoration.LineThrough
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "/ ${product.unitAr}",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Button(
                onClick = onAddToCart,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldPrimary,
                    contentColor = DarkBgPrimary
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .height(38.dp)
                    .testTag("add_product_${product.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "إضافة",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "إضافة",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}
