package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark & Gold Luxury Brand Palette - طارق الزنم (توصيل طلبات • مشاريع يومية - محافظة إب)
val DarkBgPrimary = Color(0xFF0B0D12)
val DarkCardSurface = Color(0xFF151821)
val DarkCardElevated = Color(0xFF1E222E)
val DarkOutlineGold = Color(0x66F5B915)
val DarkOutlineSubtle = Color(0xFF2B3140)

val GoldPrimary = Color(0xFFF5B915)
val GoldBright = Color(0xFFFFD54F)
val GoldDark = Color(0xFFD99B00)
val GoldContainerDark = Color(0xFF2B230E)

val TextWhite = Color(0xFFF8FAFC)
val TextMuted = Color(0xFF9CA3AF)
val SuccessGreen = Color(0xFF22C55E)

// Legacy aliases mapped to Dark & Gold palette so all screens stay cohesive
val EmeraldGreenPrimary = GoldPrimary
val EmeraldGreenLight = GoldBright
val EmeraldGreenDark = GoldBright
val EmeraldGreenContainer = DarkCardElevated
val OnEmeraldGreenContainer = GoldPrimary

val AmberAccentSecondary = GoldPrimary
val AmberAccentContainer = GoldContainerDark
val OnAmberAccentContainer = GoldBright

val TrustBlueTertiary = Color(0xFF38BDF8)
val TrustBlueContainer = Color(0xFF132638)
val OnTrustBlueContainer = Color(0xFFBAE6FD)

val MintBackgroundLight = DarkBgPrimary
val CardSurfaceLight = DarkCardSurface
val SurfaceVariantLight = DarkCardElevated
val OutlineLight = DarkOutlineSubtle

// Dark Palette
val EmeraldGreenDarkPrimary = GoldPrimary
val EmeraldGreenDarkContainer = DarkCardElevated
val AmberAccentDarkSecondary = GoldBright
val DarkBackground = DarkBgPrimary
val DarkSurface = DarkCardSurface
val DarkSurfaceVariant = DarkCardElevated
val DarkOutline = DarkOutlineSubtle

// Guarantee & status badge colors
val GoldGuarantee = GoldPrimary
val RedUrgent = Color(0xFFEF4444)
val BlueShield = Color(0xFF38BDF8)
val PurpleVip = Color(0xFFA78BFA)
