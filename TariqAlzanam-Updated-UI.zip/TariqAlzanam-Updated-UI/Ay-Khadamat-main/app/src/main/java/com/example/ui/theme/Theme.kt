package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LuxuryDarkColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = DarkBgPrimary,
    primaryContainer = DarkCardElevated,
    onPrimaryContainer = GoldBright,
    secondary = GoldDark,
    onSecondary = DarkBgPrimary,
    secondaryContainer = GoldContainerDark,
    onSecondaryContainer = GoldBright,
    tertiary = TrustBlueTertiary,
    onTertiary = DarkBgPrimary,
    tertiaryContainer = TrustBlueContainer,
    onTertiaryContainer = OnTrustBlueContainer,
    background = DarkBgPrimary,
    onBackground = TextWhite,
    surface = DarkCardSurface,
    onSurface = TextWhite,
    surfaceVariant = DarkCardElevated,
    onSurfaceVariant = TextMuted,
    outline = DarkOutlineSubtle,
    outlineVariant = DarkOutlineGold,
    error = RedUrgent,
    onError = Color.White
)

@Composable
fun AyKhadamatTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = LuxuryDarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = DarkBgPrimary.toArgb()
                window.navigationBarColor = DarkBgPrimary.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    AyKhadamatTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}
