package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CartItem
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.OutlinedTextFieldDefaults
import com.example.model.YemenGovernorate
import com.example.model.YemenLocations
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkOutlineGold
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import androidx.compose.foundation.border
import com.example.model.IbbDistricts
import com.example.ui.theme.EmeraldGreenDark
import com.example.ui.theme.DarkBgPrimary
import com.example.ui.theme.EmeraldGreenPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartBottomSheet(
    cartItems: List<CartItem>,
    currentDistrict: String,
    onUpdateQuantity: (String, Int) -> Unit,
    onRemoveItem: (String) -> Unit,
    onCheckout: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var deliveryNotes by remember { mutableStateOf("") }

    val subtotal = cartItems.sumOf { it.product.priceYer * it.quantity }
    val deliveryFee = 1000
    val total = subtotal + deliveryFee

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .testTag("cart_bottom_sheet")
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(EmeraldGreenPrimary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = null,
                            tint = EmeraldGreenPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "سلة طلباتي (${cartItems.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = MaterialTheme.colorScheme.outline
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (cartItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "سلة طلباتك فارغة حالياً",
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            } else {
                // Cart Items List
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(cartItems) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.product.nameAr,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "${item.product.priceYer} ريال × ${item.quantity} = ${item.product.priceYer * item.quantity} ريال",
                                        fontSize = 12.sp,
                                        color = EmeraldGreenPrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    if (item.specialNotes.isNotBlank()) {
                                        Text(
                                            text = "ملاحظة: ${item.specialNotes}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.outline
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { onUpdateQuantity(item.product.id, -1) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (item.quantity == 1) Icons.Default.Delete else Icons.Default.Remove,
                                            contentDescription = "إنقاص",
                                            tint = if (item.quantity == 1) Color(0xFFDC2626) else MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }

                                    Text(
                                        text = "${item.quantity}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp)
                                    )

                                    IconButton(
                                        onClick = { onUpdateQuantity(item.product.id, 1) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Add,
                                            contentDescription = "زيادة",
                                            tint = EmeraldGreenPrimary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Delivery address info
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = EmeraldGreenPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "التوصيل إلى: $currentDistrict",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Notes input
                OutlinedTextField(
                    value = deliveryNotes,
                    onValueChange = { deliveryNotes = it },
                    placeholder = { Text("أي ملاحظات للكابتن أو المتجر...", fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Guarantee assurance
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = null,
                        tint = EmeraldGreenPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "مشمول بضمان الحقيبة الحرارية والتغليف المحكم مجاناً",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldGreenDark
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Price Summary
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "قيمة الأصناف:", fontSize = 13.sp)
                    Text(text = "$subtotal ريال يمني", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "رسوم التوصيل المضمون:", fontSize = 13.sp)
                    Text(text = "$deliveryFee ريال يمني", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "المبلغ الإجمالي:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = EmeraldGreenPrimary
                    )
                    Text(
                        text = "$total ريال يمني",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = EmeraldGreenPrimary
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Place Order Button
                Button(
                    onClick = { onCheckout(deliveryNotes) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldGreenPrimary,
                        contentColor = DarkBgPrimary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("checkout_button")
                ) {
                    Text(
                        text = "تأكيد وإرسال الطلب الآن بضمان طارق الزنم",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun LocationSelectorDialog(
    currentDistrict: String,
    onSelectDistrict: (String) -> Unit,
    onDismiss: () -> Unit,
    titleText: String = "اختر المحافظة والمنطقة"
) {
    var selectedGov by remember { mutableStateOf<YemenGovernorate?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var customVillageOrStreet by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkCardSurface,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (selectedGov != null) {
                        IconButton(
                            onClick = {
                                selectedGov = null
                                searchQuery = ""
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع للمحافظات",
                                tint = GoldPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    } else {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = GoldPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(
                        text = selectedGov?.let { "محافظة ${it.nameAr}" } ?: titleText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = TextWhite
                    )
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = if (selectedGov == null) "ابحث عن محافظة أو مديرية أو شارع..." else "ابحث عن مديرية، قرية، أو شارع...",
                            fontSize = 12.sp,
                            color = Color(0xFF6B7280)
                        )
                    },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = DarkBgPrimary, modifier = Modifier.size(18.dp))
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedTextColor = DarkBgPrimary,
                        unfocusedTextColor = DarkBgPrimary,
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = Color.Transparent
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val q = searchQuery.trim()
                    if (selectedGov == null) {
                        if (q.isNotEmpty()) {
                            // Global search across all governorates and districts/villages/streets
                            val matchedPairs = YemenLocations.governorates.flatMap { gov ->
                                val govMatch = if (gov.nameAr.contains(q, ignoreCase = true)) {
                                    listOf(gov.nameAr to gov.districtsAndAreas.first())
                                } else emptyList()
                                val areaMatches = gov.districtsAndAreas
                                    .filter { it.contains(q, ignoreCase = true) }
                                    .map { gov.nameAr to it }
                                govMatch + areaMatches
                            }.distinct()

                            items(matchedPairs) { (govName, areaName) ->
                                val fullLabel = "$govName - $areaName"
                                val isSelected = fullLabel == currentDistrict
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSelected) GoldPrimary.copy(alpha = 0.2f) else DarkBgPrimary.copy(alpha = 0.6f))
                                        .border(0.8.dp, if (isSelected) GoldPrimary else DarkOutlineGold.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                                        .clickable { onSelectDistrict(fullLabel) }
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(areaName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextWhite)
                                        Text(govName, fontSize = 11.sp, color = GoldBright)
                                    }
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, null, tint = GoldPrimary, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        } else {
                            // Show all 22 Yemeni Governorates
                            items(YemenLocations.governorates) { gov ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(DarkBgPrimary.copy(alpha = 0.65f))
                                        .border(0.8.dp, DarkOutlineGold.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                        .clickable {
                                            selectedGov = gov
                                            searchQuery = ""
                                        }
                                        .padding(horizontal = 12.dp, vertical = 11.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = gov.nameAr,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = TextWhite
                                        )
                                        Text(
                                            text = "${gov.districtsAndAreas.size} مديرية ومنطقة وشارع",
                                            fontSize = 11.sp,
                                            color = TextMuted
                                        )
                                    }
                                    Text(
                                        text = "اختر ←",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = GoldPrimary
                                    )
                                }
                            }
                        }
                    } else {
                        val gov = selectedGov!!
                        val filteredAreas = if (q.isEmpty()) {
                            gov.districtsAndAreas
                        } else {
                            gov.districtsAndAreas.filter { it.contains(q, ignoreCase = true) }
                        }

                        items(filteredAreas) { area ->
                            val fullLabel = "${gov.nameAr} - $area"
                            val isSelected = fullLabel == currentDistrict || area == currentDistrict
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) GoldPrimary.copy(alpha = 0.22f) else DarkBgPrimary.copy(alpha = 0.6f))
                                    .border(0.8.dp, if (isSelected) GoldPrimary else DarkOutlineGold.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                                    .clickable { onSelectDistrict(fullLabel) }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = area,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 13.sp,
                                    color = if (isSelected) GoldBright else TextWhite
                                )
                                if (isSelected) {
                                    Icon(Icons.Default.Check, null, tint = GoldPrimary, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        // Manual village/street entry inside selected governorate
                        item {
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = customVillageOrStreet,
                                    onValueChange = { customVillageOrStreet = it },
                                    placeholder = { Text("أو اكتب قرية / شارع آخر...", fontSize = 11.sp, color = TextMuted) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = TextWhite,
                                        unfocusedTextColor = TextWhite,
                                        focusedBorderColor = GoldPrimary,
                                        unfocusedBorderColor = DarkOutlineGold
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                                Button(
                                    onClick = {
                                        val clean = customVillageOrStreet.trim()
                                        if (clean.isNotEmpty()) {
                                            onSelectDistrict("${gov.nameAr} - $clean")
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = GoldPrimary,
                                        contentColor = DarkBgPrimary
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("تأكيد", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("إغلاق", color = GoldPrimary, fontWeight = FontWeight.Bold)
            }
        }
    )
}
