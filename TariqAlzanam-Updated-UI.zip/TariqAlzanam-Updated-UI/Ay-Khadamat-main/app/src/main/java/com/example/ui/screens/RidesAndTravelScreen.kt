package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.LocalTaxi
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.AnimatedEntrance
import com.example.ui.components.GoldGradientButton
import com.example.ui.components.bounceClick
import com.example.ui.dialogs.LocationSelectorDialog
import com.example.ui.theme.DarkBgPrimary
import com.example.ui.theme.DarkCardElevated
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkOutlineGold
import com.example.ui.theme.DarkOutlineSubtle
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldContainerDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.RedUrgent
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

private data class RideOption(
    val id: String,
    val title: String,
    val subtitle: String,
    val priceHint: String,
    val icon: ImageVector
)

private data class TravelTripOption(
    val id: String,
    val carrier: String,
    val route: String,
    val time: String,
    val priceYer: String
)

@Composable
fun RidesAndTravelScreen(
    initialTab: Int = 0,
    currentDistrict: String,
    onBookRide: (rideType: String, from: String, to: String) -> Unit,
    onBookTravel: (tripMode: String, from: String, to: String, date: String, passengers: Int) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember(initialTab) { mutableIntStateOf(initialTab) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBgPrimary)
    ) {
        // Top Header matching reference images
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = DarkBgPrimary
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = GoldPrimary
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (selectedTab == 0) "المشاوير اليومية" else "حجز تذاكر سفر",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextWhite
                        )
                        Text(
                            text = "في محافظة إب",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = GoldBright
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(DarkCardSurface)
                            .border(0.8.dp, DarkOutlineGold, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (selectedTab == 0) Icons.Default.DirectionsCar else Icons.Default.FlightTakeoff,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                // Segmented Switcher: مشاوير يومية vs حجز تذاكر سفر
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(DarkCardSurface)
                        .border(0.8.dp, DarkOutlineSubtle, RoundedCornerShape(14.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ModeSwitchTab(
                        title = "مشاوير يومية",
                        icon = Icons.Default.DirectionsCar,
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        modifier = Modifier.weight(1f)
                    )
                    ModeSwitchTab(
                        title = "حجز تذاكر سفر",
                        icon = Icons.Default.FlightTakeoff,
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        AnimatedContent(
            targetState = selectedTab,
            transitionSpec = { fadeIn(tween(240)) togetherWith fadeOut(tween(180)) },
            label = "RidesTravelSwitch"
        ) { tab ->
            if (tab == 0) {
                DailyRidesContent(
                    currentDistrict = currentDistrict,
                    onBookRide = onBookRide
                )
            } else {
                TravelBookingContent(
                    onBookTravel = onBookTravel
                )
            }
        }
    }
}

@Composable
private fun ModeSwitchTab(
    title: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) GoldPrimary else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (selected) DarkBgPrimary else TextMuted,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = title,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (selected) DarkBgPrimary else TextWhite
        )
    }
}

@Composable
private fun DailyRidesContent(
    currentDistrict: String,
    onBookRide: (rideType: String, from: String, to: String) -> Unit
) {
    var fromLocation by remember { mutableStateOf(if (currentDistrict.contains("-")) currentDistrict else "إب - $currentDistrict") }
    var toLocation by remember { mutableStateOf("") }
    var showFromPicker by remember { mutableStateOf(false) }
    var showToPicker by remember { mutableStateOf(false) }

    if (showFromPicker) {
        LocationSelectorDialog(
            currentDistrict = fromLocation,
            onSelectDistrict = {
                fromLocation = it
                showFromPicker = false
            },
            onDismiss = { showFromPicker = false },
            titleText = "اختر نقطة الانطلاق (المحافظة / المنطقة)"
        )
    }

    if (showToPicker) {
        LocationSelectorDialog(
            currentDistrict = toLocation,
            onSelectDistrict = {
                toLocation = it
                showToPicker = false
            },
            onDismiss = { showToPicker = false },
            titleText = "اختر الوجهة (المحافظة / المنطقة)"
        )
    }
    var swapRotated by remember { mutableStateOf(false) }
    val swapAngle by animateFloatAsState(
        targetValue = if (swapRotated) 180f else 0f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "SwapRotate"
    )

    val rideOptions = remember {
        listOf(
            RideOption("private_car", "سيارة خاصة", "راحة وأمان تام", "ابتداءً من 1,500 ريال", Icons.Default.DirectionsCar),
            RideOption("city_ride", "مشوار داخل إب", "توصيل سريع داخل المدينة", "ابتداءً من 800 ريال", Icons.Default.LocalTaxi),
            RideOption("intercity", "مشوار بين المحافظات", "رحلات مريحة إلى أي محافظة", "حسب المسافة", Icons.Default.DirectionsBus)
        )
    }
    var selectedRide by remember { mutableStateOf(rideOptions[0]) }
    val quickDestinations = listOf("الجامعة", "المستشفى", "المديرية", "مفرق جبلة", "شارع العدين")

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Hero Banner
        item {
            AnimatedEntrance(index = 0) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, DarkOutlineGold)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(116.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_hero_banner),
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(DarkBgPrimary.copy(alpha = 0.92f), DarkBgPrimary.copy(alpha = 0.45f))
                                    )
                                )
                                .padding(14.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Column {
                                Text(
                                    text = "مشاوير آمنة وسريعة",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = GoldBright
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "كباتن موثوقون في خدمتك داخل إب وبين المحافظات",
                                    fontSize = 12.sp,
                                    color = TextWhite
                                )
                            }
                        }
                    }
                }
            }
        }

        // White Pickup/Dropoff Card with Swap Button (matching Image 1 & 2)
        item {
            AnimatedEntrance(index = 1) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Box(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = fromLocation,
                                onValueChange = { fromLocation = it },
                                label = { Text("من أين؟", fontSize = 12.sp) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = null,
                                        tint = DarkBgPrimary
                                    )
                                },
                                trailingIcon = {
                                    Text(
                                        text = "المحافظات",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = GoldPrimary,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(DarkBgPrimary)
                                            .clickable { showFromPicker = true }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoldPrimary,
                                    unfocusedBorderColor = Color(0xFFE5E7EB),
                                    focusedTextColor = DarkBgPrimary,
                                    unfocusedTextColor = DarkBgPrimary
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = toLocation,
                                onValueChange = { toLocation = it },
                                placeholder = { Text("إلى أين؟ اختر وجهتك", fontSize = 13.sp, color = Color(0xFF6B7280)) },
                                label = { Text("إلى أين؟", fontSize = 12.sp) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = null,
                                        tint = RedUrgent
                                    )
                                },
                                trailingIcon = {
                                    Text(
                                        text = "المحافظات",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = GoldPrimary,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(DarkBgPrimary)
                                            .clickable { showToPicker = true }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoldPrimary,
                                    unfocusedBorderColor = Color(0xFFE5E7EB),
                                    focusedTextColor = DarkBgPrimary,
                                    unfocusedTextColor = DarkBgPrimary
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        // Circular Dark & Gold Swap Button
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .padding(end = 12.dp)
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(DarkBgPrimary)
                                .border(1.2.dp, GoldPrimary, CircleShape)
                                .clickable {
                                    swapRotated = !swapRotated
                                    val tmp = fromLocation
                                    fromLocation = toLocation
                                    toLocation = tmp
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapVert,
                                contentDescription = "تبديل",
                                tint = GoldPrimary,
                                modifier = Modifier
                                    .size(20.dp)
                                    .rotate(swapAngle)
                            )
                        }
                    }
                }
            }
        }

        // Quick Destinations (الجامعة، المستشفى، المديرية...)
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(quickDestinations) { dest ->
                    val isPicked = toLocation == dest
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isPicked) GoldPrimary else DarkCardSurface)
                            .border(1.dp, if (isPicked) GoldPrimary else DarkOutlineGold, RoundedCornerShape(12.dp))
                            .bounceClick { toLocation = dest }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = dest,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isPicked) DarkBgPrimary else TextWhite
                        )
                    }
                }
            }
        }

        // 3 Ride Option Cards
        items(rideOptions.size) { index ->
            val option = rideOptions[index]
            val isSelected = selectedRide.id == option.id
            AnimatedEntrance(index = index + 2) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .bounceClick { selectedRide = option },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) GoldContainerDark else DarkCardSurface
                    ),
                    border = BorderStroke(
                        width = if (isSelected) 1.5.dp else 0.8.dp,
                        color = if (isSelected) GoldPrimary else DarkOutlineSubtle
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) GoldPrimary else DarkCardElevated),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = option.icon,
                                    contentDescription = option.title,
                                    tint = if (isSelected) DarkBgPrimary else GoldPrimary,
                                    modifier = Modifier.size(26.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(
                                    text = option.title,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                                Text(
                                    text = option.subtitle,
                                    fontSize = 12.sp,
                                    color = TextMuted
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = option.priceHint,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoldBright
                            )
                            if (isSelected) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "مختار",
                                    tint = GoldPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Gold Book Now Button
        item {
            Spacer(modifier = Modifier.height(4.dp))
            GoldGradientButton(
                text = "احجز مشوارك الآن",
                icon = Icons.Default.DirectionsCar,
                onClick = {
                    val dest = toLocation.ifBlank { "وسط المدينة - إب" }
                    onBookRide(selectedRide.title, fromLocation, dest)
                },
                height = 52.dp
            )
        }
    }
}

@Composable
private fun TravelBookingContent(
    onBookTravel: (tripMode: String, from: String, to: String, date: String, passengers: Int) -> Unit
) {
    var isRoundTrip by remember { mutableStateOf(false) }
    var fromCity by remember { mutableStateOf("إب") }
    var toCity by remember { mutableStateOf("صنعاء") }
    var showFromGovPicker by remember { mutableStateOf(false) }
    var showToGovPicker by remember { mutableStateOf(false) }

    if (showFromGovPicker) {
        LocationSelectorDialog(
            currentDistrict = fromCity,
            onSelectDistrict = {
                fromCity = it
                showFromGovPicker = false
            },
            onDismiss = { showFromGovPicker = false },
            titleText = "اختر محافظة/منطقة المغادرة"
        )
    }

    if (showToGovPicker) {
        LocationSelectorDialog(
            currentDistrict = toCity,
            onSelectDistrict = {
                toCity = it
                showToGovPicker = false
            },
            onDismiss = { showToGovPicker = false },
            titleText = "اختر محافظة/منطقة الوصول"
        )
    }
    var travelDate by remember { mutableStateOf("غداً - صباحاً") }
    var passengers by remember { mutableIntStateOf(1) }
    var showResults by remember { mutableStateOf(false) }

    val availableTrips = remember(fromCity, toCity) {
        listOf(
            TravelTripOption("t1", "النقل المميز VIP", "$fromCity ← $toCity", "07:30 صباحاً", "8,500 ريال"),
            TravelTripOption("t2", "حافلات اللواء الأخضر", "$fromCity ← $toCity", "01:00 ظهراً", "6,500 ريال"),
            TravelTripOption("t3", "طيران / سفر دولي", "$fromCity ← $toCity", "حسب الجدول", "تأكيد فوري")
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Hero Banner
        item {
            AnimatedEntrance(index = 0) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, DarkOutlineGold)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(DarkCardSurface, GoldContainerDark, DarkCardElevated)
                                )
                            )
                            .padding(16.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "حجز تذاكر السفر والرحلات",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = GoldBright
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "تذاكر برية وجوية من محافظة إب إلى كافة الوجهات",
                                    fontSize = 12.sp,
                                    color = TextWhite
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.FlightTakeoff,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(44.dp)
                            )
                        }
                    }
                }
            }
        }

        // One-way vs Round-trip Toggle (ذهاب فقط / ذهاب وعودة)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkCardSurface)
                    .border(0.8.dp, DarkOutlineSubtle, RoundedCornerShape(12.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(9.dp))
                        .background(if (!isRoundTrip) GoldPrimary else Color.Transparent)
                        .clickable { isRoundTrip = false }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "ذهاب فقط",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (!isRoundTrip) DarkBgPrimary else TextWhite
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(9.dp))
                        .background(if (isRoundTrip) GoldPrimary else Color.Transparent)
                        .clickable { isRoundTrip = true }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "ذهاب وعودة",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isRoundTrip) DarkBgPrimary else TextWhite
                    )
                }
            }
        }

        // White Travel Form Card
        item {
            AnimatedEntrance(index = 1) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = fromCity,
                            onValueChange = { fromCity = it },
                            label = { Text("من", fontSize = 12.sp) },
                            leadingIcon = { Icon(Icons.Default.LocationOn, null, tint = DarkBgPrimary) },
                            trailingIcon = {
                                Text(
                                    text = "المحافظات",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldPrimary,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(DarkBgPrimary)
                                        .clickable { showFromGovPicker = true }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = Color(0xFFE5E7EB),
                                focusedTextColor = DarkBgPrimary,
                                unfocusedTextColor = DarkBgPrimary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = toCity,
                            onValueChange = { toCity = it },
                            label = { Text("إلى (الوجهة)", fontSize = 12.sp) },
                            leadingIcon = { Icon(Icons.Default.FlightTakeoff, null, tint = GoldPrimary) },
                            trailingIcon = {
                                Text(
                                    text = "المحافظات",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldPrimary,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(DarkBgPrimary)
                                        .clickable { showToGovPicker = true }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = Color(0xFFE5E7EB),
                                focusedTextColor = DarkBgPrimary,
                                unfocusedTextColor = DarkBgPrimary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = travelDate,
                            onValueChange = { travelDate = it },
                            label = { Text("تاريخ السفر", fontSize = 12.sp) },
                            leadingIcon = { Icon(Icons.Default.CalendarToday, null, tint = DarkBgPrimary) },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = Color(0xFFE5E7EB),
                                focusedTextColor = DarkBgPrimary,
                                unfocusedTextColor = DarkBgPrimary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        HorizontalDivider(color = Color(0xFFE5E7EB))

                        // Passenger Count Stepper
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Person, null, tint = DarkBgPrimary)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "عدد المسافرين",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = DarkBgPrimary
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { if (passengers > 1) passengers-- },
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(DarkBgPrimary)
                                ) {
                                    Icon(Icons.Default.Remove, null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                                }
                                Text(
                                    text = passengers.toString(),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp,
                                    color = DarkBgPrimary,
                                    modifier = Modifier.padding(horizontal = 14.dp)
                                )
                                IconButton(
                                    onClick = { if (passengers < 10) passengers++ },
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(GoldPrimary)
                                ) {
                                    Icon(Icons.Default.Add, null, tint = DarkBgPrimary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Search Flights Button
        item {
            GoldGradientButton(
                text = "ابحث عن الرحلات",
                icon = Icons.Default.Search,
                onClick = { showResults = true },
                height = 52.dp
            )
        }

        // Available Trips Results
        if (showResults) {
            items(availableTrips) { trip ->
                AnimatedEntrance(index = 0) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .bounceClick {
                                val mode = if (isRoundTrip) "ذهاب وعودة" else "ذهاب فقط"
                                onBookTravel("${trip.carrier} ($mode)", fromCity, toCity, travelDate, passengers)
                            },
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                        border = BorderStroke(1.dp, DarkOutlineGold)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = trip.carrier,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                                Text(
                                    text = "${trip.route} • ${trip.time}",
                                    fontSize = 12.sp,
                                    color = TextMuted
                                )
                                Text(
                                    text = "متاح للحجز ($passengers مسافر)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = SuccessGreen
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(GoldPrimary)
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = "احجز • ${trip.priceYer}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = DarkBgPrimary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
