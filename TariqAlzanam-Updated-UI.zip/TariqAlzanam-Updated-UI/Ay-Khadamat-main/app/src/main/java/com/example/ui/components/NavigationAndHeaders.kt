package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.Screen
import com.example.ui.theme.DarkBgPrimary
import com.example.ui.theme.DarkCardElevated
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.DarkOutlineGold
import com.example.ui.theme.DarkOutlineSubtle
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun AyTopAppBar(
    currentDistrict: String,
    cartItemCount: Int,
    onDistrictClick: () -> Unit,
    onCartClick: () -> Unit,
    onGuaranteeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = DarkBgPrimary,
        tonalElevation = 0.dp,
        shadowElevation = 4.dp
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Brand Logo & Title ("طارق الزنم")
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    TariqLogoEmblem(size = 42.dp)

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "طارق الزنم",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 19.sp,
                                    color = TextWhite
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(GoldPrimary.copy(alpha = 0.16f))
                                    .border(0.6.dp, GoldPrimary.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "محافظة إب",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldBright
                                )
                            }
                        }

                        // Neighborhood Selector
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onDistrictClick() }
                                .padding(vertical = 2.dp)
                                .testTag("select_district_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = "الموقع",
                                tint = GoldPrimary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = currentDistrict,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = TextMuted
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowDown,
                                contentDescription = "تغيير",
                                tint = GoldPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // Notification/Guarantee Bell & Cart Icon
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(DarkCardSurface)
                            .border(0.8.dp, DarkOutlineGold, RoundedCornerShape(20.dp))
                            .bounceClick { onGuaranteeClick() }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("guarantee_badge_header")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "الضمان والتنبيهات",
                                tint = GoldPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "ضماننا",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoldBright
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = onCartClick,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(DarkCardSurface)
                            .border(0.8.dp, DarkOutlineSubtle, CircleShape)
                            .testTag("cart_icon_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (cartItemCount > 0) {
                                    Badge(
                                        containerColor = GoldPrimary,
                                        contentColor = DarkBgPrimary
                                    ) {
                                        Text(
                                            text = cartItemCount.toString(),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.ShoppingCart,
                                contentDescription = "سلة الطلبات",
                                tint = GoldPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
            HorizontalDivider(thickness = 0.6.dp, color = DarkOutlineGold.copy(alpha = 0.45f))
        }
    }
}

@Composable
fun AyBottomBar(
    currentScreen: Screen,
    activeOrdersCount: Int,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        HorizontalDivider(thickness = 0.8.dp, color = DarkOutlineGold.copy(alpha = 0.5f))
        NavigationBar(
            containerColor = DarkBgPrimary,
            tonalElevation = 0.dp
        ) {
            val navItemColors = NavigationBarItemDefaults.colors(
                selectedIconColor = GoldPrimary,
                selectedTextColor = GoldPrimary,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted,
                indicatorColor = GoldPrimary.copy(alpha = 0.14f)
            )

            // 1. الرئيسية
            val homeSelected = currentScreen == Screen.HOME
            val homeScale by animateFloatAsState(
                targetValue = if (homeSelected) 1.12f else 1f,
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                label = "HomeNavScale"
            )
            NavigationBarItem(
                selected = homeSelected,
                onClick = { onNavigate(Screen.HOME) },
                icon = {
                    Icon(
                        imageVector = if (homeSelected) Icons.Filled.Home else Icons.Outlined.Home,
                        contentDescription = "الرئيسية",
                        modifier = Modifier.scale(homeScale)
                    )
                },
                label = { Text("الرئيسية", fontSize = 11.sp, fontWeight = if (homeSelected) FontWeight.Bold else FontWeight.Medium) },
                colors = navItemColors,
                modifier = Modifier.testTag("nav_home")
            )

            // 2. الأقسام
            val servicesSelected = currentScreen == Screen.SERVICES_LIST
            val servicesScale by animateFloatAsState(
                targetValue = if (servicesSelected) 1.12f else 1f,
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                label = "ServicesNavScale"
            )
            NavigationBarItem(
                selected = servicesSelected,
                onClick = { onNavigate(Screen.SERVICES_LIST) },
                icon = {
                    Icon(
                        imageVector = if (servicesSelected) Icons.Filled.Category else Icons.Outlined.Category,
                        contentDescription = "الأقسام",
                        modifier = Modifier.scale(servicesScale)
                    )
                },
                label = { Text("الأقسام", fontSize = 11.sp, fontWeight = if (servicesSelected) FontWeight.Bold else FontWeight.Medium) },
                colors = navItemColors,
                modifier = Modifier.testTag("nav_services")
            )

            // 3. اطلب أي شيء (Gold Center Action)
            val customSelected = currentScreen == Screen.CUSTOM_ORDER
            val customColor by animateColorAsState(
                targetValue = if (customSelected) GoldBright else GoldPrimary,
                label = "CustomOrderNavColor"
            )
            NavigationBarItem(
                selected = customSelected,
                onClick = { onNavigate(Screen.CUSTOM_ORDER) },
                icon = {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(listOf(GoldBright, GoldDark))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddCircle,
                            contentDescription = "اطلب أي شيء",
                            tint = DarkBgPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                },
                label = {
                    Text(
                        "اطلب الآن",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = customColor
                    )
                },
                colors = navItemColors,
                modifier = Modifier.testTag("nav_custom_order")
            )

            // 4. طلباتي
            val ordersSelected = currentScreen == Screen.ORDERS || currentScreen == Screen.ORDER_TRACKING
            val ordersScale by animateFloatAsState(
                targetValue = if (ordersSelected) 1.12f else 1f,
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                label = "OrdersNavScale"
            )
            NavigationBarItem(
                selected = ordersSelected,
                onClick = { onNavigate(Screen.ORDERS) },
                icon = {
                    BadgedBox(
                        badge = {
                            if (activeOrdersCount > 0) {
                                Badge(
                                    containerColor = GoldPrimary,
                                    contentColor = DarkBgPrimary
                                ) {
                                    Text(activeOrdersCount.toString(), fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if (ordersSelected) Icons.Filled.ReceiptLong else Icons.Outlined.ReceiptLong,
                            contentDescription = "طلباتي",
                            modifier = Modifier.scale(ordersScale)
                        )
                    }
                },
                label = { Text("طلباتي", fontSize = 11.sp, fontWeight = if (ordersSelected) FontWeight.Bold else FontWeight.Medium) },
                colors = navItemColors,
                modifier = Modifier.testTag("nav_orders")
            )

            // 5. الضمان / المزيد
            val guaranteeSelected = currentScreen == Screen.GUARANTEE_INFO
            val guaranteeScale by animateFloatAsState(
                targetValue = if (guaranteeSelected) 1.12f else 1f,
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                label = "GuaranteeNavScale"
            )
            NavigationBarItem(
                selected = guaranteeSelected,
                onClick = { onNavigate(Screen.GUARANTEE_INFO) },
                icon = {
                    Icon(
                        imageVector = if (guaranteeSelected) Icons.Filled.Security else Icons.Outlined.Security,
                        contentDescription = "المزيد",
                        modifier = Modifier.scale(guaranteeScale)
                    )
                },
                label = { Text("المزيد", fontSize = 11.sp, fontWeight = if (guaranteeSelected) FontWeight.Bold else FontWeight.Medium) },
                colors = navItemColors,
                modifier = Modifier.testTag("nav_guarantee")
            )
        }
    }
}
